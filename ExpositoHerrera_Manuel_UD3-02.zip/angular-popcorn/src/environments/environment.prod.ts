export const environment = {
  production: true,
  apiBaseUrl: 'https://api.themoviedb.org/3',
  apiKey: '7dc7796c134309232ef44a970cf4df72', // Debo introducir mi API KEY de desarrollador que he obtenido en la web de TheMovieDB API.
  defaultLang: 'es-ES',
  imageBaseUrl: 'https://image.tmdb.org/t/p/w500'
};
