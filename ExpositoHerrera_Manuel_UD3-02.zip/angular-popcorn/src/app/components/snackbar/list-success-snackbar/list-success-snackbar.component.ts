import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-success-snackbar',
  templateUrl: './list-success-snackbar.component.html',
  styleUrls: ['./list-success-snackbar.component.css']
})
export class ListSuccessSnackbarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
