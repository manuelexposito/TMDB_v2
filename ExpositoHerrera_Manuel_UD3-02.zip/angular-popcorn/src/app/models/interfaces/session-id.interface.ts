export interface SessionIDResponse {
    success:    boolean;
    session_id: string;
}
